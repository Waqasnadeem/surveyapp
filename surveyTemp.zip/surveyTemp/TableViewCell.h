//
//  TableViewCell.h
//  surveyTemp
//
//  Created by Softtech Media on 25/08/2016.
//  Copyright © 2016 Softtech Media. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TableViewCell : UITableViewCell<UIActionSheetDelegate>
@property (strong, nonatomic) IBOutlet UIButton *a;
@property (strong, nonatomic) IBOutlet UIButton *b;
@property (strong, nonatomic) IBOutlet UIButton *c;
@property (strong, nonatomic) IBOutlet UIButton *d;
@property (strong, nonatomic) IBOutlet UIButton *e;
@property (strong, nonatomic) IBOutlet UIButton *f;
@property (strong, nonatomic) IBOutlet UIButton *g;
@property (strong, nonatomic) IBOutlet UIButton *h;
@property (strong, nonatomic) IBOutlet UIButton *i;
@property (strong, nonatomic) IBOutlet UIButton *j;
@property (strong, nonatomic) IBOutlet UIButton *rd1;
@property (strong, nonatomic) IBOutlet UIButton *rd2;
@property (strong, nonatomic) IBOutlet UIButton *rd3;
@property (strong, nonatomic) IBOutlet UIButton *rd4;
@property (strong, nonatomic) IBOutlet UIButton *rd5;
@property (weak, nonatomic) IBOutlet UIButton *cb1;
@property (weak, nonatomic) IBOutlet UIButton *cb2;
@property (weak, nonatomic) IBOutlet UIButton *cb3;
@property (weak, nonatomic) IBOutlet UIButton *cb4;
@property (weak, nonatomic) IBOutlet UIButton *cb5;
@property (weak, nonatomic) IBOutlet UIButton *conrd1;
@property (weak, nonatomic) IBOutlet UIButton *conrd2;
@property (weak, nonatomic) IBOutlet UIButton *dropdown1;
@property (weak, nonatomic) IBOutlet UIButton *dropdown2;
@property (weak, nonatomic) IBOutlet UIView *dropview;


@end
