//
//  TableViewCell.m
//  surveyTemp
//
//  Created by Softtech Media on 25/08/2016.
//  Copyright © 2016 Softtech Media. All rights reserved.
//

#import "TableViewCell.h"

@implementation TableViewCell

    int tags=10;

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    [self setborder];
   



}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

   }
- (IBAction)btn:(id)sender {
    NSString *colname=_noOfCol.text;
    NSArray * arrcol = [colname componentsSeparatedByString:@","];
    
    NSString *rowname=_noOfRows.text;
    NSArray * arrrow = [rowname componentsSeparatedByString:@","];

//    NSString * c=_noOfCol.text;
//    int d=[c integerValue];
//    
//    NSString * a=_noOfRows.text;
//    int b=[a integerValue];
   if(arrcol.count<=3){
    [self setTable:arrrow.count columnname:arrcol.count];
   }else{
   _noOfCol.text=@" ";
       [_noOfCol becomeFirstResponder];
   }
}
- (IBAction)clear:(id)sender {
    
        for (UIView *subview in [_dynCell.contentView subviews]) {
            // Only remove the subviews with tag not equal to 1
            if (subview.tag != 1) {
                [subview removeFromSuperview];
            }
        }
}

- (IBAction)show:(id)sender {
    int ab=10;

    for (int a=10; a<=tags; a++) {
        UITextField *textField = (UITextField*)[self.dynCell.contentView viewWithTag:ab++];
        NSString *fieldValue = textField.text;
        NSLog(@"Field %d has value: %@", ab, fieldValue);
    }
}

-(void)setTable:(int)noRows columnname:(int) col{
   // NSString * c=_noOfCol.text;
    //int d=[c integerValue];
    
    //NSString * a=_noOfRows.text;
    //int b=[a integerValue];
    NSString *colname=_noOfCol.text;
    NSArray * arrcol = [colname componentsSeparatedByString:@","];
  
    NSString *rowname=_noOfRows.text;
    NSArray * arrrow = [rowname componentsSeparatedByString:@","];
   


    if (arrrow.count>0&& arrcol.count>0) {
    
//    for (UIView *subview in [_dynCell.contentView subviews]) {
//        // Only remove the subviews with tag not equal to 1
//        if (subview.tag != 1) {
//            [subview removeFromSuperview];
//        }
//    }
        
    int xaxis=0;
    int yaxis=0;
    int lablex=0;
     int lablex1=0;
    int labley=0;
    int rowNum=0;
    for (int i=0;i<noRows;i++)
        {
            UILabel *fromLabel1 = [[UILabel alloc]initWithFrame:CGRectMake(20+lablex, 90+labley, 50, 10)];
            fromLabel1.numberOfLines = 1;
            
                        fromLabel1.text=arrrow[i];
            [fromLabel1 setFont:[UIFont systemFontOfSize:12]];
            rowNum++;

      for (int j=0; j<col; j++)
      {
            CGRect someRect = CGRectMake(70+xaxis, 80+yaxis, 100.0, 30.0);
            text = [[UITextField alloc] initWithFrame:someRect];
          tags=tags+1;
          text.tag=tags;
        xaxis=xaxis+100;
                   text.backgroundColor=[UIColor whiteColor];
        text.layer.borderWidth = 1;
    text.layer.borderColor = [[UIColor blackColor] CGColor];
      
          [_dynCell.contentView addSubview:fromLabel1];


    
  [_dynCell.contentView addSubview:text];

      }
            

            lablex=lablex+120;
            yaxis=yaxis+30;
            xaxis=0;
            lablex=0;
            labley=labley+30;
  }
    
    int colNum=0;
    for (int j=0; j<col; j++)
    {
        UILabel *fromLabel = [[UILabel alloc]initWithFrame:CGRectMake(85+lablex1, 60, 50, 10)];
        fromLabel.numberOfLines = 1;
    
    
        fromLabel.text=arrcol[j];
        [fromLabel setFont:[UIFont systemFontOfSize:12]];

        
        [_dynCell.contentView addSubview:fromLabel];
    
        lablex1=lablex1+100;
        colNum++;
    }
    }
    else{
        
        for (UIView *subview in [_dynCell.contentView subviews]) {
            // Only remove the subviews with tag not equal to 1
            if (subview.tag != 1) {
                [subview removeFromSuperview];
            }}}
 
     if (noRows>6) {  _dynCell.frame=CGRectMake(self.dynCell.frame.origin.x, self.dynCell.frame.origin.y, self.dynCell.frame.size.width, noRows*40);
         ScrView = [[UIScrollView alloc]initWithFrame:CGRectMake(self.dynCell.frame.origin.x, self.dynCell.frame.origin.y, self.dynCell.frame.size.width, noRows*40)];
    ScrView.showsVerticalScrollIndicator=YES;
   // [ScrView setBackgroundColor:[UIColor yellowColor]];
    [ScrView setScrollEnabled:YES];
    [ScrView setContentSize:CGSizeMake(0, 700)];
    [ScrView setShowsHorizontalScrollIndicator:YES];
    [ScrView setShowsVerticalScrollIndicator:YES];
    [ScrView addSubview:self.dynCell.contentView];
    [self.dynCell addSubview:ScrView];
  
       
    }
}
-(void)setborder{
    [[_a layer] setBorderWidth:2.0f];
    [[_a layer] setBorderColor:[UIColor blackColor].CGColor];
    [[_b layer] setBorderWidth:2.0f];
    [[_b layer] setBorderColor:[UIColor blackColor].CGColor];
    
    [[_c layer] setBorderWidth:2.0f];
    [[_c layer] setBorderColor:[UIColor blackColor].CGColor];
    [[_d layer] setBorderWidth:2.0f];
    [[_d layer] setBorderColor:[UIColor blackColor].CGColor];
    [[_e layer] setBorderWidth:2.0f];
    [[_e layer] setBorderColor:[UIColor blackColor].CGColor];
    [[_f layer] setBorderWidth:2.0f];
    [[_f layer] setBorderColor:[UIColor blackColor].CGColor];
    [[_g layer] setBorderWidth:2.0f];
    [[_g layer] setBorderColor:[UIColor blackColor].CGColor];
    [[_h layer] setBorderWidth:2.0f];
    [[_h layer] setBorderColor:[UIColor blackColor].CGColor];
    [[_i layer] setBorderWidth:2.0f];
    [[_i layer] setBorderColor:[UIColor blackColor].CGColor];
    [[_j layer] setBorderWidth:2.0f];
    [[_j layer] setBorderColor:[UIColor blackColor].CGColor];
    [[_dropdown1 layer] setBorderWidth:1.0f];
    [[_dropdown1 layer] setBorderColor:[UIColor blackColor].CGColor];
    
    [[_dropdown2 layer] setBorderWidth:1.0f];
    [[_dropdown2 layer] setBorderColor:[UIColor blackColor].CGColor];
}
- (IBAction)act:(id)sender {
    [_a setBackgroundColor:[UIColor blackColor]];
    [_a setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    
    [_b setBackgroundColor:[UIColor whiteColor]];
    [_b setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [_c setBackgroundColor:[UIColor whiteColor]];
    [_c setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_d setBackgroundColor:[UIColor whiteColor]];
    [_d setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_e setBackgroundColor:[UIColor whiteColor]];
    [_e setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_f setBackgroundColor:[UIColor whiteColor]];
    [_f setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_g setBackgroundColor:[UIColor whiteColor]];
    [_g setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_h setBackgroundColor:[UIColor whiteColor]];
    [_h setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_i setBackgroundColor:[UIColor whiteColor]];
    [_i setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_j setBackgroundColor:[UIColor whiteColor]];
    [_j setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
   }
- (IBAction)bb:(id)sender {
    [_b setBackgroundColor:[UIColor blackColor]];
    [_b setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    
    [_a setBackgroundColor:[UIColor whiteColor]];
    [_a setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [_c setBackgroundColor:[UIColor whiteColor]];
    [_c setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_d setBackgroundColor:[UIColor whiteColor]];
    [_d setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_e setBackgroundColor:[UIColor whiteColor]];
    [_e setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_f setBackgroundColor:[UIColor whiteColor]];
    [_f setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_g setBackgroundColor:[UIColor whiteColor]];
    [_g setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_h setBackgroundColor:[UIColor whiteColor]];
    [_h setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_i setBackgroundColor:[UIColor whiteColor]];
    [_i setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_j setBackgroundColor:[UIColor whiteColor]];
    [_j setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];

   
}
- (IBAction)cc:(id)sender {
    [_c setBackgroundColor:[UIColor blackColor]];
    [_c setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    
    [_b setBackgroundColor:[UIColor whiteColor]];
    [_b setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [_a setBackgroundColor:[UIColor whiteColor]];
    [_a setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_d setBackgroundColor:[UIColor whiteColor]];
    [_d setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_e setBackgroundColor:[UIColor whiteColor]];
    [_e setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_f setBackgroundColor:[UIColor whiteColor]];
    [_f setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_g setBackgroundColor:[UIColor whiteColor]];
    [_g setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_h setBackgroundColor:[UIColor whiteColor]];
    [_h setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_i setBackgroundColor:[UIColor whiteColor]];
    [_i setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_j setBackgroundColor:[UIColor whiteColor]];
    [_j setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];

}
- (IBAction)d:(id)sender {
    [_d setBackgroundColor:[UIColor blackColor]];
    [_d setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    
    [_b setBackgroundColor:[UIColor whiteColor]];
    [_b setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [_c setBackgroundColor:[UIColor whiteColor]];
    [_c setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_a setBackgroundColor:[UIColor whiteColor]];
    [_a setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_e setBackgroundColor:[UIColor whiteColor]];
    [_e setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_f setBackgroundColor:[UIColor whiteColor]];
    [_f setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_g setBackgroundColor:[UIColor whiteColor]];
    [_g setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_h setBackgroundColor:[UIColor whiteColor]];
    [_h setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_i setBackgroundColor:[UIColor whiteColor]];
    [_i setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_j setBackgroundColor:[UIColor whiteColor]];
    [_j setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];

}
- (IBAction)e:(id)sender {
    [_e setBackgroundColor:[UIColor blackColor]];
    [_e setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    
    [_b setBackgroundColor:[UIColor whiteColor]];
    [_b setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [_c setBackgroundColor:[UIColor whiteColor]];
    [_c setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_d setBackgroundColor:[UIColor whiteColor]];
    [_d setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_a setBackgroundColor:[UIColor whiteColor]];
    [_a setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_f setBackgroundColor:[UIColor whiteColor]];
    [_f setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_g setBackgroundColor:[UIColor whiteColor]];
    [_g setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_h setBackgroundColor:[UIColor whiteColor]];
    [_h setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_i setBackgroundColor:[UIColor whiteColor]];
    [_i setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_j setBackgroundColor:[UIColor whiteColor]];
    [_j setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];

}
- (IBAction)f:(id)sender {
    [_f setBackgroundColor:[UIColor blackColor]];
    [_f setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    
    [_b setBackgroundColor:[UIColor whiteColor]];
    [_b setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [_c setBackgroundColor:[UIColor whiteColor]];
    [_c setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_d setBackgroundColor:[UIColor whiteColor]];
    [_d setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_e setBackgroundColor:[UIColor whiteColor]];
    [_e setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_a setBackgroundColor:[UIColor whiteColor]];
    [_a setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_g setBackgroundColor:[UIColor whiteColor]];
    [_g setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_h setBackgroundColor:[UIColor whiteColor]];
    [_h setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_i setBackgroundColor:[UIColor whiteColor]];
    [_i setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_j setBackgroundColor:[UIColor whiteColor]];
    [_j setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];

}
- (IBAction)g:(id)sender {
    [_g setBackgroundColor:[UIColor blackColor]];
    [_g setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    
    [_b setBackgroundColor:[UIColor whiteColor]];
    [_b setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [_c setBackgroundColor:[UIColor whiteColor]];
    [_c setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_d setBackgroundColor:[UIColor whiteColor]];
    [_d setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_e setBackgroundColor:[UIColor whiteColor]];
    [_e setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_f setBackgroundColor:[UIColor whiteColor]];
    [_f setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_a setBackgroundColor:[UIColor whiteColor]];
    [_a setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_h setBackgroundColor:[UIColor whiteColor]];
    [_h setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_i setBackgroundColor:[UIColor whiteColor]];
    [_i setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_j setBackgroundColor:[UIColor whiteColor]];
    [_j setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];

}
- (IBAction)h:(id)sender {
    [_h setBackgroundColor:[UIColor blackColor]];
    [_h setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    
    [_b setBackgroundColor:[UIColor whiteColor]];
    [_b setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [_c setBackgroundColor:[UIColor whiteColor]];
    [_c setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_d setBackgroundColor:[UIColor whiteColor]];
    [_d setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_e setBackgroundColor:[UIColor whiteColor]];
    [_e setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_f setBackgroundColor:[UIColor whiteColor]];
    [_f setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_g setBackgroundColor:[UIColor whiteColor]];
    [_g setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_a setBackgroundColor:[UIColor whiteColor]];
    [_a setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_i setBackgroundColor:[UIColor whiteColor]];
    [_i setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_j setBackgroundColor:[UIColor whiteColor]];
    [_j setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];

}
- (IBAction)i:(id)sender {
    [_i setBackgroundColor:[UIColor blackColor]];
    [_i setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    
    [_b setBackgroundColor:[UIColor whiteColor]];
    [_b setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [_c setBackgroundColor:[UIColor whiteColor]];
    [_c setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_d setBackgroundColor:[UIColor whiteColor]];
    [_d setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_e setBackgroundColor:[UIColor whiteColor]];
    [_e setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_f setBackgroundColor:[UIColor whiteColor]];
    [_f setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_g setBackgroundColor:[UIColor whiteColor]];
    [_g setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_h setBackgroundColor:[UIColor whiteColor]];
    [_h setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_a setBackgroundColor:[UIColor whiteColor]];
    [_a setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_j setBackgroundColor:[UIColor whiteColor]];
    [_j setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];

}
- (IBAction)j:(id)sender {
    [_j setBackgroundColor:[UIColor blackColor]];
    [_j setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    
    [_b setBackgroundColor:[UIColor whiteColor]];
    [_b setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [_c setBackgroundColor:[UIColor whiteColor]];
    [_c setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_d setBackgroundColor:[UIColor whiteColor]];
    [_d setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_e setBackgroundColor:[UIColor whiteColor]];
    [_e setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_f setBackgroundColor:[UIColor whiteColor]];
    [_f setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_g setBackgroundColor:[UIColor whiteColor]];
    [_g setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_h setBackgroundColor:[UIColor whiteColor]];
    [_h setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_i setBackgroundColor:[UIColor whiteColor]];
    [_i setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_a setBackgroundColor:[UIColor whiteColor]];
    [_a setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];

}
- (IBAction)rd1:(id)sender {
    [_rd1 setImage:[UIImage imageNamed:@"selected_radio_button.png"] forState:UIControlStateNormal];
    [_rd2 setImage:[UIImage imageNamed:@"un_selected_radio_button.png"] forState:UIControlStateNormal];
    [_rd3 setImage:[UIImage imageNamed:@"un_selected_radio_button.png"] forState:UIControlStateNormal];
    [_rd4 setImage:[UIImage imageNamed:@"un_selected_radio_button.png"] forState:UIControlStateNormal];
    [_rd5 setImage:[UIImage imageNamed:@"un_selected_radio_button.png"] forState:UIControlStateNormal];
    
}
- (IBAction)rd2:(id)sender {
    [_rd1 setImage:[UIImage imageNamed:@"un_selected_radio_button.png"] forState:UIControlStateNormal];
    [_rd2 setImage:[UIImage imageNamed:@"selected_radio_button.png"] forState:UIControlStateNormal];
    [_rd3 setImage:[UIImage imageNamed:@"un_selected_radio_button.png"] forState:UIControlStateNormal];
    [_rd4 setImage:[UIImage imageNamed:@"un_selected_radio_button.png"] forState:UIControlStateNormal];
    [_rd5 setImage:[UIImage imageNamed:@"un_selected_radio_button.png"] forState:UIControlStateNormal];
    

}

- (IBAction)rd3:(id)sender {
    [_rd1 setImage:[UIImage imageNamed:@"un_selected_radio_button.png"] forState:UIControlStateNormal];
    [_rd2 setImage:[UIImage imageNamed:@"un_selected_radio_button.png"] forState:UIControlStateNormal];
    [_rd3 setImage:[UIImage imageNamed:@"selected_radio_button.png"] forState:UIControlStateNormal];
    [_rd4 setImage:[UIImage imageNamed:@"un_selected_radio_button.png"] forState:UIControlStateNormal];
    [_rd5 setImage:[UIImage imageNamed:@"un_selected_radio_button.png"] forState:UIControlStateNormal];
    

}

- (IBAction)rd4:(id)sender {
    [_rd1 setImage:[UIImage imageNamed:@"un_selected_radio_button.png"] forState:UIControlStateNormal];
    [_rd2 setImage:[UIImage imageNamed:@"un_selected_radio_button.png"] forState:UIControlStateNormal];
    [_rd3 setImage:[UIImage imageNamed:@"un_selected_radio_button.png"] forState:UIControlStateNormal];
    [_rd4 setImage:[UIImage imageNamed:@"selected_radio_button.png"] forState:UIControlStateNormal];
    [_rd5 setImage:[UIImage imageNamed:@"un_selected_radio_button.png"] forState:UIControlStateNormal];
    

}
- (IBAction)rd5:(id)sender {
    [_rd1 setImage:[UIImage imageNamed:@"un_selected_radio_button.png"] forState:UIControlStateNormal];
    [_rd2 setImage:[UIImage imageNamed:@"un_selected_radio_button.png"] forState:UIControlStateNormal];
    [_rd3 setImage:[UIImage imageNamed:@"un_selected_radio_button.png"] forState:UIControlStateNormal];
    [_rd4 setImage:[UIImage imageNamed:@"un_selected_radio_button.png"] forState:UIControlStateNormal];
    [_rd5 setImage:[UIImage imageNamed:@"selected_radio_button.png"] forState:UIControlStateNormal];
    

}

- (IBAction)cb1:(id)sender {
    if( ![[_cb1 imageForState:UIControlStateNormal] isEqual:[UIImage imageNamed:@"checked.png"]])
    {
    [_cb1 setImage:[UIImage imageNamed:@"checked.png"] forState:UIControlStateNormal];
    }
    else{
     [_cb1 setImage:[UIImage imageNamed:@"unchecked.png"] forState:UIControlStateNormal];
    
    }
}


- (IBAction)cb2:(id)sender {
    if( ![[_cb2 imageForState:UIControlStateNormal] isEqual:[UIImage imageNamed:@"checked.png"]])
    {
        [_cb2 setImage:[UIImage imageNamed:@"checked.png"] forState:UIControlStateNormal];
    }
    else{
        [_cb2 setImage:[UIImage imageNamed:@"unchecked.png"] forState:UIControlStateNormal];
        
    }
}
- (IBAction)cb3:(id)sender {
    if( ![[_cb3 imageForState:UIControlStateNormal] isEqual:[UIImage imageNamed:@"checked.png"]])
    {
        [_cb3 setImage:[UIImage imageNamed:@"checked.png"] forState:UIControlStateNormal];
    }
    else{
        [_cb3 setImage:[UIImage imageNamed:@"unchecked.png"] forState:UIControlStateNormal];
        
    }}
- (IBAction)cb4:(id)sender {
    if( ![[_cb4 imageForState:UIControlStateNormal] isEqual:[UIImage imageNamed:@"checked.png"]])
    {
        [_cb4 setImage:[UIImage imageNamed:@"checked.png"] forState:UIControlStateNormal];
    }
    else{
        [_cb4 setImage:[UIImage imageNamed:@"unchecked.png"] forState:UIControlStateNormal];
        
    }
}
- (IBAction)cb5:(id)sender {
    if( ![[_cb5 imageForState:UIControlStateNormal] isEqual:[UIImage imageNamed:@"checked.png"]])
    {
        [_cb5 setImage:[UIImage imageNamed:@"checked.png"] forState:UIControlStateNormal];
    }
    else{
        [_cb5 setImage:[UIImage imageNamed:@"unchecked.png"] forState:UIControlStateNormal];
        
    }
}
- (IBAction)conrd1:(id)sender {
    [_conrd2 setImage:[UIImage imageNamed:@"un_selected_radio_button.png"] forState:UIControlStateNormal];
    [_conrd1 setImage:[UIImage imageNamed:@"selected_radio_button.png"] forState:UIControlStateNormal];
}


- (IBAction)conrd2:(id)sender {
    [_conrd1 setImage:[UIImage imageNamed:@"un_selected_radio_button.png"] forState:UIControlStateNormal];
    [_conrd2 setImage:[UIImage imageNamed:@"selected_radio_button.png"] forState:UIControlStateNormal];


}
- (IBAction)dropdown1:(id)sender {
    UIActionSheet *popup = [[UIActionSheet alloc] initWithTitle:@"Select option:" delegate:self cancelButtonTitle:nil destructiveButtonTitle:nil otherButtonTitles:
                            @"Health",
                            @"Non-profit",
                            @"Technology",
                            @"Transpotation",
                            @"Energy",
                            @"IT",
                            @"Government",
                            @"Manufacturing",
                            
                            
                            
                            nil];
    popup.tag = 1;
    
    [popup showInView:self.dropview];
}
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    return YES;
}

// It is important for you to hide the keyboard
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [_txt1 resignFirstResponder];
    [_txt2 resignFirstResponder];
    return YES;
}
- (IBAction)dropdown2:(id)sender {
    UIActionSheet *popup = [[UIActionSheet alloc] initWithTitle:@"Select option:" delegate:self cancelButtonTitle:nil destructiveButtonTitle:nil otherButtonTitles:
                            @"Health",
                            @"Non-profit",
                            @"Technology",
                            @"Transpotation",
                            @"Energy",
                            @"IT",
                            @"Government",
                            @"Manufacturing",



                            nil];
    popup.tag = 1;
    
    [popup showInView:self.dropview];
}
- (void)actionSheet:(UIActionSheet *)popup clickedButtonAtIndex:(NSInteger)buttonIndex {
    NSString *title;
    switch (popup.tag) {
        case 1: {
            switch (buttonIndex) {
                case 0:
                    title=[popup buttonTitleAtIndex:buttonIndex];
                                       [_dropdown1 setTitle:title forState:UIControlStateNormal];

                    break;
                case 1:
                    title=[popup buttonTitleAtIndex:buttonIndex];
                    [_dropdown1 setTitle:title forState:UIControlStateNormal];
                    

                    break;
                case 2:
                    title=[popup buttonTitleAtIndex:buttonIndex];
                    [_dropdown1 setTitle:title forState:UIControlStateNormal];
                    

                    break;
                case 3:
                    title=[popup buttonTitleAtIndex:buttonIndex];
                    [_dropdown1 setTitle:title forState:UIControlStateNormal];
                    

                    break;
                case 4:
                    title=[popup buttonTitleAtIndex:buttonIndex];
                    [_dropdown1 setTitle:title forState:UIControlStateNormal];
                    

                    break;
                case 5:
                    title=[popup buttonTitleAtIndex:buttonIndex];
                    [_dropdown1 setTitle:title forState:UIControlStateNormal];
                    
                    
                    break;
                case 6:
                    title=[popup buttonTitleAtIndex:buttonIndex];
                    [_dropdown1 setTitle:title forState:UIControlStateNormal];
                    
                    
                    break;
                case 7:
                    title=[popup buttonTitleAtIndex:buttonIndex];
                    [_dropdown1 setTitle:title forState:UIControlStateNormal];
                    
                    
                    break;
                case 8:
                    title=[popup buttonTitleAtIndex:buttonIndex];
                    [_dropdown1 setTitle:title forState:UIControlStateNormal];
                    
                    
                    break;
                    
                default:
                    break;
            }
            break;
        }
        default:
            break;
    }
}
@end
