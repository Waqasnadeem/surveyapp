//
//  TableViewCell.m
//  surveyTemp
//
//  Created by Softtech Media on 25/08/2016.
//  Copyright © 2016 Softtech Media. All rights reserved.
//

#import "TableViewCell.h"

@implementation TableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    [self setborder];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
-(void)setborder{
    [[_a layer] setBorderWidth:2.0f];
    [[_a layer] setBorderColor:[UIColor blackColor].CGColor];
    [[_b layer] setBorderWidth:2.0f];
    [[_b layer] setBorderColor:[UIColor blackColor].CGColor];
    
    [[_c layer] setBorderWidth:2.0f];
    [[_c layer] setBorderColor:[UIColor blackColor].CGColor];
    [[_d layer] setBorderWidth:2.0f];
    [[_d layer] setBorderColor:[UIColor blackColor].CGColor];
    [[_e layer] setBorderWidth:2.0f];
    [[_e layer] setBorderColor:[UIColor blackColor].CGColor];
    [[_f layer] setBorderWidth:2.0f];
    [[_f layer] setBorderColor:[UIColor blackColor].CGColor];
    [[_g layer] setBorderWidth:2.0f];
    [[_g layer] setBorderColor:[UIColor blackColor].CGColor];
    [[_h layer] setBorderWidth:2.0f];
    [[_h layer] setBorderColor:[UIColor blackColor].CGColor];
    [[_i layer] setBorderWidth:2.0f];
    [[_i layer] setBorderColor:[UIColor blackColor].CGColor];
    [[_j layer] setBorderWidth:2.0f];
    [[_j layer] setBorderColor:[UIColor blackColor].CGColor];
    [[_dropdown1 layer] setBorderWidth:1.0f];
    [[_dropdown1 layer] setBorderColor:[UIColor blackColor].CGColor];
    
    [[_dropdown2 layer] setBorderWidth:1.0f];
    [[_dropdown2 layer] setBorderColor:[UIColor blackColor].CGColor];
}
- (IBAction)act:(id)sender {
    [_a setBackgroundColor:[UIColor blackColor]];
    [_a setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    
    [_b setBackgroundColor:[UIColor whiteColor]];
    [_b setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [_c setBackgroundColor:[UIColor whiteColor]];
    [_c setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_d setBackgroundColor:[UIColor whiteColor]];
    [_d setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_e setBackgroundColor:[UIColor whiteColor]];
    [_e setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_f setBackgroundColor:[UIColor whiteColor]];
    [_f setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_g setBackgroundColor:[UIColor whiteColor]];
    [_g setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_h setBackgroundColor:[UIColor whiteColor]];
    [_h setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_i setBackgroundColor:[UIColor whiteColor]];
    [_i setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_j setBackgroundColor:[UIColor whiteColor]];
    [_j setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
   }
- (IBAction)bb:(id)sender {
    [_b setBackgroundColor:[UIColor blackColor]];
    [_b setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    
    [_a setBackgroundColor:[UIColor whiteColor]];
    [_a setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [_c setBackgroundColor:[UIColor whiteColor]];
    [_c setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_d setBackgroundColor:[UIColor whiteColor]];
    [_d setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_e setBackgroundColor:[UIColor whiteColor]];
    [_e setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_f setBackgroundColor:[UIColor whiteColor]];
    [_f setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_g setBackgroundColor:[UIColor whiteColor]];
    [_g setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_h setBackgroundColor:[UIColor whiteColor]];
    [_h setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_i setBackgroundColor:[UIColor whiteColor]];
    [_i setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_j setBackgroundColor:[UIColor whiteColor]];
    [_j setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];

   
}
- (IBAction)cc:(id)sender {
    [_c setBackgroundColor:[UIColor blackColor]];
    [_c setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    
    [_b setBackgroundColor:[UIColor whiteColor]];
    [_b setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [_a setBackgroundColor:[UIColor whiteColor]];
    [_a setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_d setBackgroundColor:[UIColor whiteColor]];
    [_d setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_e setBackgroundColor:[UIColor whiteColor]];
    [_e setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_f setBackgroundColor:[UIColor whiteColor]];
    [_f setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_g setBackgroundColor:[UIColor whiteColor]];
    [_g setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_h setBackgroundColor:[UIColor whiteColor]];
    [_h setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_i setBackgroundColor:[UIColor whiteColor]];
    [_i setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_j setBackgroundColor:[UIColor whiteColor]];
    [_j setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];

}
- (IBAction)d:(id)sender {
    [_d setBackgroundColor:[UIColor blackColor]];
    [_d setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    
    [_b setBackgroundColor:[UIColor whiteColor]];
    [_b setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [_c setBackgroundColor:[UIColor whiteColor]];
    [_c setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_a setBackgroundColor:[UIColor whiteColor]];
    [_a setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_e setBackgroundColor:[UIColor whiteColor]];
    [_e setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_f setBackgroundColor:[UIColor whiteColor]];
    [_f setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_g setBackgroundColor:[UIColor whiteColor]];
    [_g setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_h setBackgroundColor:[UIColor whiteColor]];
    [_h setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_i setBackgroundColor:[UIColor whiteColor]];
    [_i setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_j setBackgroundColor:[UIColor whiteColor]];
    [_j setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];

}
- (IBAction)e:(id)sender {
    [_e setBackgroundColor:[UIColor blackColor]];
    [_e setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    
    [_b setBackgroundColor:[UIColor whiteColor]];
    [_b setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [_c setBackgroundColor:[UIColor whiteColor]];
    [_c setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_d setBackgroundColor:[UIColor whiteColor]];
    [_d setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_a setBackgroundColor:[UIColor whiteColor]];
    [_a setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_f setBackgroundColor:[UIColor whiteColor]];
    [_f setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_g setBackgroundColor:[UIColor whiteColor]];
    [_g setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_h setBackgroundColor:[UIColor whiteColor]];
    [_h setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_i setBackgroundColor:[UIColor whiteColor]];
    [_i setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_j setBackgroundColor:[UIColor whiteColor]];
    [_j setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];

}
- (IBAction)f:(id)sender {
    [_f setBackgroundColor:[UIColor blackColor]];
    [_f setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    
    [_b setBackgroundColor:[UIColor whiteColor]];
    [_b setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [_c setBackgroundColor:[UIColor whiteColor]];
    [_c setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_d setBackgroundColor:[UIColor whiteColor]];
    [_d setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_e setBackgroundColor:[UIColor whiteColor]];
    [_e setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_a setBackgroundColor:[UIColor whiteColor]];
    [_a setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_g setBackgroundColor:[UIColor whiteColor]];
    [_g setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_h setBackgroundColor:[UIColor whiteColor]];
    [_h setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_i setBackgroundColor:[UIColor whiteColor]];
    [_i setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_j setBackgroundColor:[UIColor whiteColor]];
    [_j setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];

}
- (IBAction)g:(id)sender {
    [_g setBackgroundColor:[UIColor blackColor]];
    [_g setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    
    [_b setBackgroundColor:[UIColor whiteColor]];
    [_b setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [_c setBackgroundColor:[UIColor whiteColor]];
    [_c setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_d setBackgroundColor:[UIColor whiteColor]];
    [_d setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_e setBackgroundColor:[UIColor whiteColor]];
    [_e setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_f setBackgroundColor:[UIColor whiteColor]];
    [_f setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_a setBackgroundColor:[UIColor whiteColor]];
    [_a setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_h setBackgroundColor:[UIColor whiteColor]];
    [_h setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_i setBackgroundColor:[UIColor whiteColor]];
    [_i setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_j setBackgroundColor:[UIColor whiteColor]];
    [_j setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];

}
- (IBAction)h:(id)sender {
    [_h setBackgroundColor:[UIColor blackColor]];
    [_h setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    
    [_b setBackgroundColor:[UIColor whiteColor]];
    [_b setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [_c setBackgroundColor:[UIColor whiteColor]];
    [_c setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_d setBackgroundColor:[UIColor whiteColor]];
    [_d setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_e setBackgroundColor:[UIColor whiteColor]];
    [_e setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_f setBackgroundColor:[UIColor whiteColor]];
    [_f setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_g setBackgroundColor:[UIColor whiteColor]];
    [_g setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_a setBackgroundColor:[UIColor whiteColor]];
    [_a setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_i setBackgroundColor:[UIColor whiteColor]];
    [_i setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_j setBackgroundColor:[UIColor whiteColor]];
    [_j setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];

}
- (IBAction)i:(id)sender {
    [_i setBackgroundColor:[UIColor blackColor]];
    [_i setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    
    [_b setBackgroundColor:[UIColor whiteColor]];
    [_b setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [_c setBackgroundColor:[UIColor whiteColor]];
    [_c setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_d setBackgroundColor:[UIColor whiteColor]];
    [_d setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_e setBackgroundColor:[UIColor whiteColor]];
    [_e setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_f setBackgroundColor:[UIColor whiteColor]];
    [_f setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_g setBackgroundColor:[UIColor whiteColor]];
    [_g setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_h setBackgroundColor:[UIColor whiteColor]];
    [_h setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_a setBackgroundColor:[UIColor whiteColor]];
    [_a setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_j setBackgroundColor:[UIColor whiteColor]];
    [_j setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];

}
- (IBAction)j:(id)sender {
    [_j setBackgroundColor:[UIColor blackColor]];
    [_j setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    
    [_b setBackgroundColor:[UIColor whiteColor]];
    [_b setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [_c setBackgroundColor:[UIColor whiteColor]];
    [_c setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_d setBackgroundColor:[UIColor whiteColor]];
    [_d setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_e setBackgroundColor:[UIColor whiteColor]];
    [_e setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_f setBackgroundColor:[UIColor whiteColor]];
    [_f setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_g setBackgroundColor:[UIColor whiteColor]];
    [_g setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_h setBackgroundColor:[UIColor whiteColor]];
    [_h setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_i setBackgroundColor:[UIColor whiteColor]];
    [_i setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    [_a setBackgroundColor:[UIColor whiteColor]];
    [_a setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];

}
- (IBAction)rd1:(id)sender {
    [_rd1 setImage:[UIImage imageNamed:@"selected_radio_button.png"] forState:UIControlStateNormal];
    [_rd2 setImage:[UIImage imageNamed:@"un_selected_radio_button.png"] forState:UIControlStateNormal];
    [_rd3 setImage:[UIImage imageNamed:@"un_selected_radio_button.png"] forState:UIControlStateNormal];
    [_rd4 setImage:[UIImage imageNamed:@"un_selected_radio_button.png"] forState:UIControlStateNormal];
    [_rd5 setImage:[UIImage imageNamed:@"un_selected_radio_button.png"] forState:UIControlStateNormal];
    
}
- (IBAction)rd2:(id)sender {
    [_rd1 setImage:[UIImage imageNamed:@"un_selected_radio_button.png"] forState:UIControlStateNormal];
    [_rd2 setImage:[UIImage imageNamed:@"selected_radio_button.png"] forState:UIControlStateNormal];
    [_rd3 setImage:[UIImage imageNamed:@"un_selected_radio_button.png"] forState:UIControlStateNormal];
    [_rd4 setImage:[UIImage imageNamed:@"un_selected_radio_button.png"] forState:UIControlStateNormal];
    [_rd5 setImage:[UIImage imageNamed:@"un_selected_radio_button.png"] forState:UIControlStateNormal];
    

}

- (IBAction)rd3:(id)sender {
    [_rd1 setImage:[UIImage imageNamed:@"un_selected_radio_button.png"] forState:UIControlStateNormal];
    [_rd2 setImage:[UIImage imageNamed:@"un_selected_radio_button.png"] forState:UIControlStateNormal];
    [_rd3 setImage:[UIImage imageNamed:@"selected_radio_button.png"] forState:UIControlStateNormal];
    [_rd4 setImage:[UIImage imageNamed:@"un_selected_radio_button.png"] forState:UIControlStateNormal];
    [_rd5 setImage:[UIImage imageNamed:@"un_selected_radio_button.png"] forState:UIControlStateNormal];
    

}

- (IBAction)rd4:(id)sender {
    [_rd1 setImage:[UIImage imageNamed:@"un_selected_radio_button.png"] forState:UIControlStateNormal];
    [_rd2 setImage:[UIImage imageNamed:@"un_selected_radio_button.png"] forState:UIControlStateNormal];
    [_rd3 setImage:[UIImage imageNamed:@"un_selected_radio_button.png"] forState:UIControlStateNormal];
    [_rd4 setImage:[UIImage imageNamed:@"selected_radio_button.png"] forState:UIControlStateNormal];
    [_rd5 setImage:[UIImage imageNamed:@"un_selected_radio_button.png"] forState:UIControlStateNormal];
    

}
- (IBAction)rd5:(id)sender {
    [_rd1 setImage:[UIImage imageNamed:@"un_selected_radio_button.png"] forState:UIControlStateNormal];
    [_rd2 setImage:[UIImage imageNamed:@"un_selected_radio_button.png"] forState:UIControlStateNormal];
    [_rd3 setImage:[UIImage imageNamed:@"un_selected_radio_button.png"] forState:UIControlStateNormal];
    [_rd4 setImage:[UIImage imageNamed:@"un_selected_radio_button.png"] forState:UIControlStateNormal];
    [_rd5 setImage:[UIImage imageNamed:@"selected_radio_button.png"] forState:UIControlStateNormal];
    

}

- (IBAction)cb1:(id)sender {
    if( ![[_cb1 imageForState:UIControlStateNormal] isEqual:[UIImage imageNamed:@"checked.png"]])
    {
    [_cb1 setImage:[UIImage imageNamed:@"checked.png"] forState:UIControlStateNormal];
    }
    else{
     [_cb1 setImage:[UIImage imageNamed:@"unchecked.png"] forState:UIControlStateNormal];
    
    }
}


- (IBAction)cb2:(id)sender {
    if( ![[_cb2 imageForState:UIControlStateNormal] isEqual:[UIImage imageNamed:@"checked.png"]])
    {
        [_cb2 setImage:[UIImage imageNamed:@"checked.png"] forState:UIControlStateNormal];
    }
    else{
        [_cb2 setImage:[UIImage imageNamed:@"unchecked.png"] forState:UIControlStateNormal];
        
    }
}
- (IBAction)cb3:(id)sender {
    if( ![[_cb3 imageForState:UIControlStateNormal] isEqual:[UIImage imageNamed:@"checked.png"]])
    {
        [_cb3 setImage:[UIImage imageNamed:@"checked.png"] forState:UIControlStateNormal];
    }
    else{
        [_cb3 setImage:[UIImage imageNamed:@"unchecked.png"] forState:UIControlStateNormal];
        
    }}
- (IBAction)cb4:(id)sender {
    if( ![[_cb4 imageForState:UIControlStateNormal] isEqual:[UIImage imageNamed:@"checked.png"]])
    {
        [_cb4 setImage:[UIImage imageNamed:@"checked.png"] forState:UIControlStateNormal];
    }
    else{
        [_cb4 setImage:[UIImage imageNamed:@"unchecked.png"] forState:UIControlStateNormal];
        
    }
}
- (IBAction)cb5:(id)sender {
    if( ![[_cb5 imageForState:UIControlStateNormal] isEqual:[UIImage imageNamed:@"checked.png"]])
    {
        [_cb5 setImage:[UIImage imageNamed:@"checked.png"] forState:UIControlStateNormal];
    }
    else{
        [_cb5 setImage:[UIImage imageNamed:@"unchecked.png"] forState:UIControlStateNormal];
        
    }
}
- (IBAction)conrd1:(id)sender {
    [_conrd2 setImage:[UIImage imageNamed:@"un_selected_radio_button.png"] forState:UIControlStateNormal];
    [_conrd1 setImage:[UIImage imageNamed:@"selected_radio_button.png"] forState:UIControlStateNormal];
}


- (IBAction)conrd2:(id)sender {
    [_conrd1 setImage:[UIImage imageNamed:@"un_selected_radio_button.png"] forState:UIControlStateNormal];
    [_conrd2 setImage:[UIImage imageNamed:@"selected_radio_button.png"] forState:UIControlStateNormal];


}
- (IBAction)dropdown1:(id)sender {
    UIActionSheet *popup = [[UIActionSheet alloc] initWithTitle:@"Select option:" delegate:self cancelButtonTitle:nil destructiveButtonTitle:nil otherButtonTitles:
                            @"Health",
                            @"Non-profit",
                            @"Technology",
                            @"Transpotation",
                            @"Energy",
                            @"IT",
                            @"Government",
                            @"Manufacturing",
                            
                            
                            
                            nil];
    popup.tag = 1;
    
    [popup showInView:self.dropview];
}
- (IBAction)dropdown2:(id)sender {
    UIActionSheet *popup = [[UIActionSheet alloc] initWithTitle:@"Select option:" delegate:self cancelButtonTitle:nil destructiveButtonTitle:nil otherButtonTitles:
                            @"Health",
                            @"Non-profit",
                            @"Technology",
                            @"Transpotation",
                            @"Energy",
                            @"IT",
                            @"Government",
                            @"Manufacturing",



                            nil];
    popup.tag = 1;
    
    [popup showInView:self.dropview];
}
- (void)actionSheet:(UIActionSheet *)popup clickedButtonAtIndex:(NSInteger)buttonIndex {
    NSString *title;
    switch (popup.tag) {
        case 1: {
            switch (buttonIndex) {
                case 0:
                    title=[popup buttonTitleAtIndex:buttonIndex];
                                       [_dropdown1 setTitle:title forState:UIControlStateNormal];

                    break;
                case 1:
                    title=[popup buttonTitleAtIndex:buttonIndex];
                    [_dropdown1 setTitle:title forState:UIControlStateNormal];
                    

                    break;
                case 2:
                    title=[popup buttonTitleAtIndex:buttonIndex];
                    [_dropdown1 setTitle:title forState:UIControlStateNormal];
                    

                    break;
                case 3:
                    title=[popup buttonTitleAtIndex:buttonIndex];
                    [_dropdown1 setTitle:title forState:UIControlStateNormal];
                    

                    break;
                case 4:
                    title=[popup buttonTitleAtIndex:buttonIndex];
                    [_dropdown1 setTitle:title forState:UIControlStateNormal];
                    

                    break;
                case 5:
                    title=[popup buttonTitleAtIndex:buttonIndex];
                    [_dropdown1 setTitle:title forState:UIControlStateNormal];
                    
                    
                    break;
                case 6:
                    title=[popup buttonTitleAtIndex:buttonIndex];
                    [_dropdown1 setTitle:title forState:UIControlStateNormal];
                    
                    
                    break;
                case 7:
                    title=[popup buttonTitleAtIndex:buttonIndex];
                    [_dropdown1 setTitle:title forState:UIControlStateNormal];
                    
                    
                    break;
                case 8:
                    title=[popup buttonTitleAtIndex:buttonIndex];
                    [_dropdown1 setTitle:title forState:UIControlStateNormal];
                    
                    
                    break;
                    
                default:
                    break;
            }
            break;
        }
        default:
            break;
    }
}
@end
