//
//  AppDelegate.h
//  surveyTemp
//
//  Created by Softtech Media on 25/08/2016.
//  Copyright © 2016 Softtech Media. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

