//
//  ViewController.h
//  surveyTemp
//
//  Created by Softtech Media on 25/08/2016.
//  Copyright © 2016 Softtech Media. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController<UITextFieldDelegate>

@property (strong, nonatomic) IBOutlet UILabel *questionList;

@property (strong, nonatomic) IBOutlet UIButton *nxtq;
@property (strong, nonatomic) IBOutlet UIButton *prevbtn;
@property (strong, nonatomic) IBOutlet UIButton *done;

@end

