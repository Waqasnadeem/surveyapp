//
//  ViewController.m
//  surveyTemp
//
//  Created by Softtech Media on 25/08/2016.
//  Copyright © 2016 Softtech Media. All rights reserved.
//

#import "ViewController.h"
#import "TableViewCell.h"

@interface ViewController ()
{
    NSArray * finalarr;
   
    NSUInteger inx;
    TableViewCell *tb;
    NSArray *nibArray;
}
@property (strong, nonatomic) IBOutlet UIView *view1;
@end
int i=0;
@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    //to load a cell xib
   
    [[_done layer] setBorderWidth:2.0f];
    [[_done layer] setBorderColor:[UIColor blackColor].CGColor];
    _done.hidden=YES;

    NSString* path = [[NSBundle mainBundle] pathForResource:@"txti"
                                                     ofType:@"rtf"];
    NSString* content = [NSString stringWithContentsOfFile:path
                                                  encoding:NSUTF8StringEncoding
                                                     error:NULL];
    
    NSArray * arr = [content componentsSeparatedByString:@"/*/"];
    NSString *get= arr[1];
 finalarr = [get componentsSeparatedByString:@"/**/"];
    _questionList.text=finalarr[i];
    if(_questionList.text==finalarr[0]){
        _done.hidden=YES;
        _prevbtn.enabled=NO;
        _nxtq.hidden=NO;
    }
    // NSLog(@"%@",content);
   nibArray = [[NSBundle mainBundle] loadNibNamed:@"TableViewCell" owner:self options:nil];
      tb = (TableViewCell *)[nibArray objectAtIndex:i];
    NSString* last=[finalarr lastObject];
  inx=[finalarr indexOfObject:last];
    
    [self ConfigNextQButton];
    [self ConfigPrevQButton];
    [self.view1 addSubview:tb];
     
    
   

   
}
-(void) ConfigNextQButton{
    _nxtq.frame=CGRectMake(226, 200+ tb.frame.size.height, 151, 42);
    _nxtq.layer.cornerRadius = 4;
    [[_nxtq layer] setBorderWidth:2.0f];
    [[_nxtq layer] setBorderColor:[UIColor blackColor].CGColor];


}
-(void) ConfigPrevQButton{
    _prevbtn.frame=CGRectMake(30, 200+ tb.frame.size.height, 151, 42);
    _prevbtn.layer.cornerRadius = 4;
    [[_prevbtn layer] setBorderWidth:2.0f];
    [[_prevbtn layer] setBorderColor:[UIColor blackColor].CGColor];
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(NSInteger)findIndex{
    
        NSInteger index=  [finalarr indexOfObject:_questionList.text];
        
    

    return index;

}

- (IBAction)prevbtn:(id)sender {
    @try {
        
        NSInteger call=  [self findIndex];
        call=call-1;
        if(i<=0){
           
        }
        else{
          
         i=i-1;
        }
        NSString*ele= finalarr[call];
        _questionList.text=ele;
                NSUInteger index = [finalarr indexOfObject:ele];
        if (index == ([finalarr count]-1))
        {
            _done.hidden=NO;
            _nxtq.hidden=YES;
            _prevbtn.enabled=YES;

        }
        else if(ele==finalarr[0]){
            _done.hidden=YES;
            _prevbtn.enabled=NO;
            _nxtq.hidden=NO;
        }
        else{
            _done.hidden=YES;
            _prevbtn.enabled=YES;

            _nxtq.hidden=NO;
        
        }

        tb = (TableViewCell *)[nibArray objectAtIndex:i];
        [self.view1 addSubview:tb];
    } @catch (NSException *exception) {
        
    } @finally {
        
    }

}
- (IBAction)nxtq:(id)sender {
    @try { _prevbtn.enabled=YES;

        
     NSInteger call=  [self findIndex];
        call++;
        i++;
        NSString*ele= finalarr[call];
        _questionList.text=ele;
        NSUInteger index = [finalarr indexOfObject:ele];
        if (index == ([finalarr count]-1))
        {
            _done.hidden=NO;
            _nxtq.hidden=YES; _prevbtn.enabled=YES;

        }

         tb = (TableViewCell *)[nibArray objectAtIndex:i];
          [self.view1 addSubview:tb];
    } @catch (NSException *exception) {
        
    } @finally {
        
    }

}

@end
